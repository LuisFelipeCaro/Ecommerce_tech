# Simple Browser files

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.
